# Getting Started

## HTML

```
<html>
	<head>
		<title> My first HTML Page</title>
	</head>
	<body>
		My first html page with body
	</body>
</html>
```

## JSP

/src/main/resources/META-INF/resources/WEB-INF/jsp/sayHello.jsp

/say-hello-jsp => SayHelloController - sayHelloJsp method => sayHello

/WEB-INF/jsp/sayHello.jsp


