import './App.css';
import LearningComponent from './components/learning-examples/LearningComponent'

function App() {
  return (
    <div className="App">
      <LearningComponent />
    </div>
  )
}

export default App;
